# My Furniture
Merupakan web toko online yang menjual beberapa furniture. Terdapat halaman user yang digunakan untuk memesan product dan halaman admin yang digunakan untuk mengelola data web. Web ini merupakan tugas dalam salah satu matakuliah di kampus.

### Teknologi yang digunakan
* XAMPP
* VS Code
* MySQL
* PHP
* HTML & CSS

### Demo Web
* [clien](http://myfurniture.arifnurrohman.xyz)
* [admin](http://myfurniture.arifnurrohman.xyz/admin)

### Admin Akun
* username  : admin
* password  : admin
